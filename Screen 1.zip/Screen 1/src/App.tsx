import { useEffect } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  BarChart3,
  Bell,
  Building,
  Building2,
  ChevronDown,
  ChevronsUpDown,
  CircleDollarSign,
  Compass,
  FileText,
  Filter,
  Gem,
  Layers,
  LayoutDashboard,
  LineChart as LucideLineChart,
  Loader,
  Map,
  Minus,
  Percent,
  Plus,
  Radio,
  RotateCcw,
  Search,
  SearchX,
  Settings,
  SlidersHorizontal,
  TrendingDown,
  TrendingUp,
  TriangleAlert,
  Trophy,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function App() {
  return (
    <div>
      <div className="bg-zinc-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="flex w-full h-270 overflow-hidden">
          <aside className="shrink-0 bg-zinc-900 border-white/10 border-t-0 border-r-1 border-b-0 border-l-0 border-solid flex p-6 flex-col justify-between w-64">
            <div className="flex flex-col gap-8">
              <div className="flex items-center gap-2">
                <div className="size-9 ring-1 ring-primary/40 rounded-xl bg-[#155dfc]/15 flex justify-center items-center">
                  <Gem className="size-5 text-[#155dfc]" />
                </div>
                <div className="flex flex-col">
                  <span className="font-semibold text-neutral-50 text-sm leading-5 tracking-tight">
                    Quartz Yield
                  </span>
                  <span className="text-[#9f9fa9] text-[11px]">
                    Institutional Suite
                  </span>
                </div>
              </div>
              <nav className="flex flex-col justify-start items-stretch gap-1">
                <Button
                  variant="ghost"
                  className="rounded-lg bg-zinc-800 text-neutral-50 justify-start gap-2 h-10"
                >
                  <LayoutDashboard className="size-4 text-[#155dfc]" />
                  Dashboard
                </Button>
                <Button
                  variant="ghost"
                  className="rounded-lg text-[#9f9fa9] justify-start gap-2 h-10"
                >
                  <Map className="size-4" />
                  Communities
                </Button>
                <Button
                  variant="ghost"
                  className="rounded-lg text-[#9f9fa9] justify-start gap-2 h-10"
                >
                  <Building2 className="size-4" />
                  Assets
                </Button>
                <Button
                  variant="ghost"
                  className="rounded-lg text-[#9f9fa9] justify-start gap-2 h-10"
                >
                  <Filter className="size-4" />
                  Sourcing Matrix
                </Button>
                <Button
                  variant="ghost"
                  className="rounded-lg text-[#9f9fa9] justify-start gap-2 h-10"
                >
                  <FileText className="size-4" />
                  Prospectus
                </Button>
                <Button
                  variant="ghost"
                  className="rounded-lg text-[#9f9fa9] justify-start gap-2 h-10"
                >
                  <BarChart3 className="size-4" />
                  Reports
                </Button>
                <Button
                  variant="ghost"
                  className="rounded-lg text-[#9f9fa9] justify-start gap-2 h-10"
                >
                  <Settings className="size-4" />
                  Settings
                </Button>
              </nav>
            </div>
            <div className="rounded-xl bg-zinc-900 border-white/10 border-1 border-solid flex p-4 items-center gap-3">
              <div className="size-9 ring-1 ring-primary/40 rounded-full overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1608800114496-b5c808bd09b4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxEdWJhaSUyMHNreWxpbmUlMjBhZXJpYWwlMjBuaWdodHxlbnwxfDJ8fHwxNzgzMzY2MTY4fDA&ixlib=rb-4.1.0&q=80&w=400"
                  alt="User"
                  className="object-cover w-full h-full"
                  data-photoid="7YZIAQF4zRw"
                  data-authorname="Jassem Mohamed"
                  data-authorurl="https://unsplash.com/@j4ssem"
                  data-blurhash="L2397bN3xtp09Ft7W-oyrlp0j{V["
                />
              </div>
              <div className="flex flex-col flex-1">
                <span className="font-medium text-neutral-50 text-xs leading-4">
                  A. Rahman
                </span>
                <span className="text-[#9f9fa9] text-[11px]">
                  Portfolio Lead
                </span>
              </div>
              <ChevronsUpDown className="size-4 text-[#9f9fa9]" />
            </div>
          </aside>
          <div className="flex flex-col flex-1 overflow-hidden">
            <header className="shrink-0 bg-zinc-950/95 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid">
              <div className="border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex px-6 py-2 items-center gap-2">
                <span className="font-semibold rounded-full bg-[#00bc7d]/15 text-[#00bc7d] text-[11px] flex px-2.5 py-1 items-center gap-1.5">
                  <Radio className="size-3" />
                  DLD LIVE
                </span>
                <div className="whitespace-nowrap text-[#9f9fa9] text-xs leading-4 flex items-center flex-1 gap-8 overflow-hidden">
                  <span className="flex items-center gap-1.5">
                    <ArrowUpRight className="size-3 text-[#00bc7d]" />
                    Downtown Dubai · AED 4.2M · Apartment
                  </span>
                  <span className="flex items-center gap-1.5">
                    <ArrowUpRight className="size-3 text-[#00bc7d]" />
                    Palm Jumeirah · AED 18.5M · Villa
                  </span>
                  <span className="flex items-center gap-1.5">
                    <ArrowDownRight className="size-3 text-[#ff6467]" />
                    Business Bay · AED 1.9M · Office
                  </span>
                  <span className="flex items-center gap-1.5">
                    <ArrowUpRight className="size-3 text-[#00bc7d]" />
                    Dubai Marina · AED 3.1M · Apartment
                  </span>
                  <span className="flex items-center gap-1.5">
                    <ArrowUpRight className="size-3 text-[#00bc7d]" />
                    JVC · AED 890K · Studio
                  </span>
                </div>
              </div>
              <div className="flex px-6 py-4 justify-between items-center">
                <div className="flex flex-col">
                  <h1 className="font-semibold text-neutral-50 text-lg leading-7 tracking-tight">
                    Global Investment Dashboard
                  </h1>
                  <p className="text-[#9f9fa9] text-xs leading-4">
                    Dubai · Net Yield Intelligence Overview
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="relative w-80">
                    <Search className="top-1/2 size-4 -translate-y-1/2 text-[#9f9fa9] absolute left-3" />
                    <Input
                      placeholder="Search communities, assets, transactions..."
                      className="rounded-lg bg-zinc-900 text-sm leading-5 border-black/1 border-0 border-solid pl-9 h-9"
                    />
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-9 rounded-lg text-[#9f9fa9]"
                  >
                    <Bell className="size-4" />
                  </Button>
                  <div className="size-9 ring-1 ring-primary/50 rounded-full overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1608800114496-b5c808bd09b4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxEdWJhaSUyMHNreWxpbmUlMjBhZXJpYWwlMjBuaWdodHxlbnwxfDJ8fHwxNzgzMzY2MTY4fDA&ixlib=rb-4.1.0&q=80&w=400"
                      alt="Profile"
                      className="object-cover w-full h-full"
                      data-photoid="7YZIAQF4zRw"
                      data-authorname="Jassem Mohamed"
                      data-authorurl="https://unsplash.com/@j4ssem"
                      data-blurhash="L2397bN3xtp09Ft7W-oyrlp0j{V["
                    />
                  </div>
                </div>
              </div>
            </header>
            <div className="grid shrink-0 grid-cols-4 px-6 py-4 gap-4">
              <Card className="shadow-[0_0_0_1px_oklch(0.488_0.243_264.376/0.15)] rounded-2xl bg-zinc-900 border-white/10 border-1 border-solid p-5 gap-2">
                <CardHeader className="flex p-0 flex-row justify-between items-center gap-2">
                  <span className="text-[#9f9fa9] text-xs leading-4">
                    Total Transaction Volume
                  </span>
                  <CircleDollarSign className="size-4 text-[#155dfc]" />
                </CardHeader>
                <CardContent className="flex p-0 flex-col gap-1">
                  <span className="font-semibold text-neutral-50 text-2xl leading-8 tracking-tight">
                    AED 82.4B
                  </span>
                  <span className="text-[#00bc7d] text-xs leading-4 flex items-center gap-1">
                    <TrendingUp className="size-3" />
                    +12.8% vs last quarter
                  </span>
                </CardContent>
              </Card>
              <Card className="shadow-[0_0_0_1px_oklch(0.488_0.243_264.376/0.15)] rounded-2xl bg-zinc-900 border-white/10 border-1 border-solid p-5 gap-2">
                <CardHeader className="flex p-0 flex-row justify-between items-center gap-2">
                  <span className="text-[#9f9fa9] text-xs leading-4">
                    Average Net Yield
                  </span>
                  <Percent className="size-4 text-[#155dfc]" />
                </CardHeader>
                <CardContent className="flex p-0 flex-col gap-1">
                  <span className="font-semibold text-neutral-50 text-2xl leading-8 tracking-tight">
                    6.74%
                  </span>
                  <span className="text-[#00bc7d] text-xs leading-4 flex items-center gap-1">
                    <TrendingUp className="size-3" />
                    +0.42 pts YoY
                  </span>
                </CardContent>
              </Card>
              <Card className="shadow-[0_0_0_1px_oklch(0.488_0.243_264.376/0.15)] rounded-2xl bg-zinc-900 border-white/10 border-1 border-solid p-5 gap-2">
                <CardHeader className="flex p-0 flex-row justify-between items-center gap-2">
                  <span className="text-[#9f9fa9] text-xs leading-4">
                    Active Listings
                  </span>
                  <Building className="size-4 text-[#155dfc]" />
                </CardHeader>
                <CardContent className="flex p-0 flex-col gap-1">
                  <span className="font-semibold text-neutral-50 text-2xl leading-8 tracking-tight">
                    14,208
                  </span>
                  <span className="text-[#00bc7d] text-xs leading-4 flex items-center gap-1">
                    <TrendingUp className="size-3" />
                    +3.1% this month
                  </span>
                </CardContent>
              </Card>
              <Card className="shadow-[0_0_0_1px_oklch(0.488_0.243_264.376/0.15)] rounded-2xl bg-zinc-900 border-white/10 border-1 border-solid p-5 gap-2">
                <CardHeader className="flex p-0 flex-row justify-between items-center gap-2">
                  <span className="text-[#9f9fa9] text-xs leading-4">
                    YoY Price Growth
                  </span>
                  <LucideLineChart className="size-4 text-[#155dfc]" />
                </CardHeader>
                <CardContent className="flex p-0 flex-col gap-1">
                  <span className="font-semibold text-neutral-50 text-2xl leading-8 tracking-tight">
                    -1.9%
                  </span>
                  <span className="text-[#ff6467] text-xs leading-4 flex items-center gap-1">
                    <TrendingDown className="size-3" />
                    Cooling in prime zones
                  </span>
                </CardContent>
              </Card>
            </div>
            <div className="flex px-6 pb-6 flex-1 gap-4 overflow-hidden">
              <Card className="shrink-0 rounded-2xl bg-zinc-900 border-white/10 border-1 border-solid flex p-6 flex-col gap-4 w-80">
                <CardHeader className="flex p-0 flex-row justify-between items-center gap-2">
                  <div className="flex items-center gap-2">
                    <Filter className="size-4 text-[#155dfc]" />
                    <span className="font-semibold text-neutral-50 text-sm leading-5">
                      Asset Sourcing Matrix
                    </span>
                  </div>
                  <SlidersHorizontal className="size-4 text-[#9f9fa9]" />
                </CardHeader>
                <CardContent className="flex p-0 flex-col flex-1 gap-6">
                  <div className="flex flex-col gap-2">
                    <div className="flex justify-between items-center">
                      <label className="font-medium text-neutral-50 text-xs leading-4">
                        Net Yield % Range
                      </label>
                      <span className="text-[#155dfc] text-xs leading-4">
                        4.5% – 9.0%
                      </span>
                    </div>
                    <div className="rounded-full bg-zinc-800 flex items-center w-full h-2">
                      <div className="ml-[15%] w-[55%] rounded-full bg-[#155dfc] h-2" />
                    </div>
                    <div className="flex justify-between">
                      <span className="size-3 rounded-full bg-zinc-950 border-[#155dfc] border-2 border-solid" />
                    </div>
                  </div>
                  <div className="flex flex-col gap-2">
                    <div className="flex justify-between items-center">
                      <label className="font-medium text-neutral-50 text-xs leading-4">
                        Budget (AED)
                      </label>
                      <span className="text-[#155dfc] text-xs leading-4">
                        1M – 12M
                      </span>
                    </div>
                    <div className="rounded-full bg-zinc-800 flex items-center w-full h-2">
                      <div className="ml-[8%] w-[62%] rounded-full bg-[#155dfc] h-2" />
                    </div>
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="font-medium text-neutral-50 text-xs leading-4">
                      Property Type
                    </label>
                    <Select>
                      <SelectTrigger className="rounded-lg bg-zinc-800 text-sm leading-5 border-black/1 border-0 border-solid w-full h-9">
                        <SelectValue placeholder="All Types" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="apartment">Apartment</SelectItem>
                        <SelectItem value="villa">Villa</SelectItem>
                        <SelectItem value="office">Office</SelectItem>
                        <SelectItem value="townhouse">Townhouse</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="font-medium text-neutral-50 text-xs leading-4">
                      Community
                    </label>
                    <Select>
                      <SelectTrigger className="rounded-lg bg-zinc-800 text-sm leading-5 border-black/1 border-0 border-solid w-full h-9">
                        <SelectValue placeholder="Select community" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="marina">Dubai Marina</SelectItem>
                        <SelectItem value="downtown">Downtown Dubai</SelectItem>
                        <SelectItem value="jvc">JVC</SelectItem>
                        <SelectItem value="palm">Palm Jumeirah</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="rounded-xl bg-zinc-800/40 border-white/10 border-1 border-solid flex p-4 flex-col gap-2">
                    <div className="text-[#9f9fa9] text-xs leading-4 flex items-center gap-2">
                      <Layers className="size-3.5 text-[#155dfc]" />
                      Heatmap Layer Density
                    </div>
                    <div className="rounded-full bg-zinc-800 flex items-center w-full h-1.5">
                      <div className="w-[78%] rounded-full bg-[#fe9a00] h-1.5" />
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex p-0 flex-col gap-2">
                  <Button className="rounded-lg bg-[#155dfc] text-[#1c398e] gap-2 w-full h-10">
                    <Search className="size-4" />
                    Run Sourcing Query
                  </Button>
                  <Button
                    variant="ghost"
                    className="rounded-lg text-[#9f9fa9] gap-2 w-full h-9"
                  >
                    <RotateCcw className="size-3.5" />
                    Reset Filters
                  </Button>
                </CardFooter>
              </Card>
              <div className="relative shadow-[0_0_0_1px_oklch(0.488_0.243_264.376/0.2)] rounded-2xl bg-zinc-950 border-white/10 border-1 border-solid flex-1 overflow-hidden">
                <img
                  src="https://screens-image-components-public.s3.eu-north-1.amazonaws.com/city-map-2d.png"
                  alt="Dubai interactive map"
                  className="object-cover opacity-95 w-full h-full"
                />
                <div className="bg-[radial-gradient(circle_at_40%_45%,oklch(0.696_0.17_162.48/0.35),transparent_25%),radial-gradient(circle_at_58%_38%,oklch(0.769_0.188_70.08/0.4),transparent_20%),radial-gradient(circle_at_50%_60%,oklch(0.645_0.246_16.439/0.3),transparent_22%)] absolute inset-0" />
                <div className="bg-[linear-gradient(to_bottom,oklch(0.141_0.005_285.823/0.45),transparent_30%,oklch(0.141_0.005_285.823/0.35))] absolute inset-0" />
                <div className="backdrop-blur-xl rounded-lg bg-zinc-900/80 border-white/10 border-1 border-solid flex absolute left-4 top-4 px-3 py-2 items-center gap-2">
                  <Map className="size-4 text-[#155dfc]" />
                  <span className="font-medium text-neutral-50 text-xs leading-4">
                    Net Yield Intensity · Dubai
                  </span>
                </div>
                <div className="backdrop-blur-xl rounded-lg bg-[#fe9a00]/15 border-[#fe9a00]/50 border-1 border-solid flex absolute right-4 top-4 px-3 py-2 items-center gap-2">
                  <TriangleAlert className="size-4 text-[#fe9a00]" />
                  <span className="text-[#fe9a00] text-xs leading-4">
                    Query beyond DLD-covered bounds
                  </span>
                </div>
                <div className="top-1/2 backdrop-blur-xl rounded-lg bg-zinc-900/80 border-white/10 border-1 border-solid flex absolute right-4 p-1 flex-col gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-8 rounded-md text-neutral-50"
                  >
                    <Plus className="size-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-8 rounded-md text-neutral-50"
                  >
                    <Minus className="size-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-8 rounded-md text-neutral-50"
                  >
                    <Compass className="size-4" />
                  </Button>
                </div>
                <div className="backdrop-blur-xl rounded-xl bg-zinc-900/80 border-white/10 border-1 border-solid flex absolute left-4 bottom-4 p-4 flex-col gap-2">
                  <span className="font-medium text-neutral-50 text-[11px]">
                    Yield Intensity
                  </span>
                  <div className="bg-[linear-gradient(to_right,oklch(0.645_0.246_16.439),oklch(0.769_0.188_70.08),oklch(0.696_0.17_162.48))] rounded-full w-40 h-2" />
                  <div className="text-[#9f9fa9] text-[10px] flex justify-between">
                    <span>Low 3%</span>
                    <span>High 9%+</span>
                  </div>
                </div>
                <div className="backdrop-blur-xl rounded-lg bg-zinc-900/80 text-[#9f9fa9] text-[11px] border-white/10 border-1 border-solid flex absolute right-4 bottom-4 px-3 py-2 items-center gap-2">
                  <Loader className="size-3.5 animate-spin text-[#155dfc]" />
                  Recalculating polygon density...
                </div>
              </div>
              <Card className="shrink-0 rounded-2xl bg-zinc-900 border-white/10 border-1 border-solid flex p-6 flex-col gap-4 w-96 overflow-hidden">
                <CardHeader className="flex p-0 flex-row justify-between items-center gap-2">
                  <div className="flex items-center gap-2">
                    <Trophy className="size-4 text-[#155dfc]" />
                    <span className="font-semibold text-neutral-50 text-sm leading-5">
                      Top Communities
                    </span>
                  </div>
                  <Badge
                    variant="secondary"
                    className="rounded-full text-[11px]"
                  >
                    142 results
                  </Badge>
                </CardHeader>
                <CardContent className="flex p-0 flex-col flex-1 overflow-hidden">
                  <div className="grid grid-cols-[1.4fr_0.9fr_0.9fr_0.9fr] border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid pb-2 gap-2">
                    <button className="font-medium text-left text-[#9f9fa9] text-[11px] flex items-center gap-1">
                      Community
                      <ChevronsUpDown className="size-3" />
                    </button>
                    <button className="font-medium text-[#155dfc] text-[11px] flex items-center gap-1">
                      Yield
                      <ChevronDown className="size-3" />
                    </button>
                    <button className="font-medium text-[#9f9fa9] text-[11px] flex items-center gap-1">
                      Txns
                      <ChevronsUpDown className="size-3" />
                    </button>
                    <button className="font-medium text-[#9f9fa9] text-[11px] flex items-center gap-1">
                      Price/ft
                      <ChevronsUpDown className="size-3" />
                    </button>
                  </div>
                  <div className="divide-y divide-border overflow-y-auto flex flex-col flex-1">
                    <div className="grid grid-cols-[1.4fr_0.9fr_0.9fr_0.9fr] py-3 items-center gap-2">
                      <span className="text-neutral-50 text-sm leading-5">
                        JVC
                      </span>
                      <span className="font-medium text-[#00bc7d] text-sm leading-5">
                        8.9%
                      </span>
                      <span className="text-[#9f9fa9] text-sm leading-5">
                        1,204
                      </span>
                      <span className="text-[#9f9fa9] text-sm leading-5">
                        920
                      </span>
                    </div>
                    <div className="grid grid-cols-[1.4fr_0.9fr_0.9fr_0.9fr] py-3 items-center gap-2">
                      <span className="text-neutral-50 text-sm leading-5">
                        Dubai Sports City
                      </span>
                      <span className="font-medium text-[#00bc7d] text-sm leading-5">
                        8.4%
                      </span>
                      <span className="text-[#9f9fa9] text-sm leading-5">
                        876
                      </span>
                      <span className="text-[#9f9fa9] text-sm leading-5">
                        840
                      </span>
                    </div>
                    <div className="grid grid-cols-[1.4fr_0.9fr_0.9fr_0.9fr] py-3 items-center gap-2">
                      <span className="text-neutral-50 text-sm leading-5">
                        Dubai Marina
                      </span>
                      <span className="font-medium text-[#00bc7d] text-sm leading-5">
                        7.2%
                      </span>
                      <span className="text-[#9f9fa9] text-sm leading-5">
                        2,341
                      </span>
                      <span className="text-[#9f9fa9] text-sm leading-5">
                        1,650
                      </span>
                    </div>
                    <div className="grid grid-cols-[1.4fr_0.9fr_0.9fr_0.9fr] py-3 items-center gap-2">
                      <span className="text-neutral-50 text-sm leading-5">
                        Business Bay
                      </span>
                      <span className="font-medium text-[#fe9a00] text-sm leading-5">
                        6.8%
                      </span>
                      <span className="text-[#9f9fa9] text-sm leading-5">
                        1,987
                      </span>
                      <span className="text-[#9f9fa9] text-sm leading-5">
                        1,480
                      </span>
                    </div>
                    <div className="grid grid-cols-[1.4fr_0.9fr_0.9fr_0.9fr] py-3 items-center gap-2">
                      <span className="text-neutral-50 text-sm leading-5">
                        Downtown Dubai
                      </span>
                      <span className="font-medium text-[#fe9a00] text-sm leading-5">
                        5.9%
                      </span>
                      <span className="text-[#9f9fa9] text-sm leading-5">
                        1,543
                      </span>
                      <span className="text-[#9f9fa9] text-sm leading-5">
                        2,340
                      </span>
                    </div>
                    <div className="grid grid-cols-[1.4fr_0.9fr_0.9fr_0.9fr] py-3 items-center gap-2">
                      <span className="text-neutral-50 text-sm leading-5">
                        Palm Jumeirah
                      </span>
                      <span className="font-medium text-[#ff6467] text-sm leading-5">
                        4.6%
                      </span>
                      <span className="text-[#9f9fa9] text-sm leading-5">
                        612
                      </span>
                      <span className="text-[#9f9fa9] text-sm leading-5">
                        3,120
                      </span>
                    </div>
                    <div className="grid grid-cols-[1.4fr_0.9fr_0.9fr_0.9fr] py-3 items-center gap-2">
                      <span className="text-neutral-50 text-sm leading-5">
                        Emirates Hills
                      </span>
                      <span className="font-medium text-[#ff6467] text-sm leading-5">
                        4.1%
                      </span>
                      <span className="text-[#9f9fa9] text-sm leading-5">
                        198
                      </span>
                      <span className="text-[#9f9fa9] text-sm leading-5">
                        2,890
                      </span>
                    </div>
                    <div className="grid grid-cols-[1.4fr_0.9fr_0.9fr_0.9fr] py-3 items-center gap-2">
                      <span className="text-neutral-50 text-sm leading-5">
                        Arabian Ranches
                      </span>
                      <span className="font-medium text-[#00bc7d] text-sm leading-5">
                        7.0%
                      </span>
                      <span className="text-[#9f9fa9] text-sm leading-5">
                        734
                      </span>
                      <span className="text-[#9f9fa9] text-sm leading-5">
                        1,120
                      </span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="border-white/10 border-t-1 border-r-0 border-b-0 border-l-0 border-solid flex px-0 pt-4 pb-0 flex-col gap-3">
                  <div className="rounded-xl bg-zinc-800/30 border-white/10 border-1 border-dashed flex p-4 items-center gap-3 w-full">
                    <SearchX className="size-6 text-[#9f9fa9]" />
                    <div className="flex flex-col">
                      <span className="font-medium text-neutral-50 text-xs leading-4">
                        No assets match current criteria
                      </span>
                      <span className="text-[#9f9fa9] text-[11px]">
                        Adjust yield or budget filters to expand results.
                      </span>
                    </div>
                  </div>
                </CardFooter>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useEffect } from "react";
import {
  AlertTriangle,
  BarChart3,
  Bell,
  Building2,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Compass,
  Copy,
  Diamond,
  Download,
  FileText,
  Filter,
  Layers3,
  LayoutDashboard,
  Link,
  LoaderCircle,
  Mail,
  Map,
  Minus,
  Plus,
  RadioTower,
  RotateCcw,
  Search,
  SearchX,
  Settings,
  SlidersHorizontal,
  TrendingDown,
  TrendingUp,
} from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

import { FallbackComponent } from "./CustomComponents";

export default function App() {
  return (
    <div>
      <div className="bg-zinc-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="relative flex w-full h-270 overflow-hidden">
          <nav className="shrink-0 bg-zinc-900 border-white/10 border-t-0 border-r-1 border-b-0 border-l-0 border-solid flex p-6 flex-col gap-8 w-70 h-full">
            <div className="flex px-2 items-center gap-3">
              <div className="size-10 shadow-[0_0_24px_oklch(0.546_0.245_262.881/.35)] rounded-xl bg-[#155dfc] flex justify-center items-center">
                <Diamond className="size-5 text-[#1c398e]" />
              </div>
              <div className="flex flex-col">
                <span className="font-semibold text-neutral-50 text-base leading-6 tracking-tight">
                  Quartz Yield
                </span>
                <span className="text-[#9f9fa9] text-xs leading-4">
                  Institutional Suite
                </span>
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <Button
                variant="ghost"
                className="bg-zinc-800/70 text-neutral-50 px-3 justify-start gap-3"
              >
                <LayoutDashboard className="size-4" />
                Dashboard
              </Button>
              <Button
                variant="ghost"
                className="text-[#9f9fa9] px-3 justify-start gap-3"
              >
                <Map className="size-4" />
                Communities
              </Button>
              <Button
                variant="ghost"
                className="text-[#9f9fa9] px-3 justify-start gap-3"
              >
                <Building2 className="size-4" />
                Assets
              </Button>
              <Button
                variant="ghost"
                className="text-[#9f9fa9] px-3 justify-start gap-3"
              >
                <Filter className="size-4" />
                Sourcing Matrix
              </Button>
              <Button
                variant="ghost"
                className="text-[#9f9fa9] px-3 justify-start gap-3"
              >
                <FileText className="size-4" />
                Prospectus
              </Button>
              <Button
                variant="ghost"
                className="text-[#9f9fa9] px-3 justify-start gap-3"
              >
                <BarChart3 className="size-4" />
                Reports
              </Button>
              <Button
                variant="ghost"
                className="text-[#9f9fa9] px-3 justify-start gap-3"
              >
                <Settings className="size-4" />
                Settings
              </Button>
            </div>
            <div className="rounded-2xl bg-zinc-900 border-white/10 border-1 border-solid flex mt-auto p-4 items-center gap-3">
              <Avatar className="size-10">
                <AvatarFallback className="bg-[#155dfc] text-[#1c398e]">
                  AR
                </AvatarFallback>
              </Avatar>
              <div className="flex flex-col">
                <span className="font-medium text-neutral-50 text-sm leading-5">
                  A. Rahman
                </span>
                <span className="text-[#9f9fa9] text-xs leading-4">
                  Portfolio Lead
                </span>
              </div>
              <FallbackComponent className="size-4 text-[#9f9fa9] ml-auto" />
            </div>
          </nav>
          <div className="flex flex-col flex-1 overflow-hidden">
            <header className="backdrop-blur-sm bg-zinc-950/95 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid flex px-8 flex-col justify-center gap-4 h-30">
              <div className="flex justify-between items-center gap-6">
                <div className="flex items-center gap-3 overflow-hidden">
                  <div className="rounded-full bg-zinc-800 border-white/10 border-1 border-solid flex px-4 py-2 items-center gap-2">
                    <RadioTower className="size-4 text-[#00bc7d]" />
                    <span className="whitespace-nowrap font-medium text-[#00bc7d] text-sm leading-5">
                      DLD LIVE
                    </span>
                  </div>
                  <div className="whitespace-nowrap text-[#9f9fa9] text-sm leading-5 flex items-center gap-6 overflow-hidden">
                    <span className="flex items-center gap-2">
                      <TrendingUp className="size-3.5 text-[#00bc7d]" />
                      Downtown Dubai · AED 4.2M · Apartment
                    </span>
                    <span className="flex items-center gap-2">
                      <TrendingUp className="size-3.5 text-[#00bc7d]" />
                      Palm Jumeirah · AED 18.5M · Villa
                    </span>
                    <span className="flex items-center gap-2">
                      <TrendingDown className="size-3.5 text-[#ff6467]" />
                      Business Bay · AED 1.9M · Office
                    </span>
                    <span className="flex items-center gap-2">
                      <TrendingUp className="size-3.5 text-[#00bc7d]" />
                      Dubai Marina · AED 3.1M · Apartment
                    </span>
                    <span className="flex items-center gap-2">
                      <TrendingUp className="size-3.5 text-[#00bc7d]" />
                      JVC · AED 890K · Studio
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="rounded-2xl bg-zinc-900 text-[#9f9fa9] border-white/10 border-1 border-solid flex px-4 py-3 items-center gap-3 w-90">
                    <Search className="size-4" />
                    <span className="text-sm leading-5">
                      Search communities, assets, transactions.
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-[#9f9fa9]"
                  >
                    <Bell className="size-4" />
                  </Button>
                  <Avatar className="size-10 border-white/10 border-1 border-solid">
                    <AvatarFallback className="bg-zinc-800 text-neutral-50">
                      QY
                    </AvatarFallback>
                  </Avatar>
                </div>
              </div>
              <div className="flex justify-between items-end">
                <div>
                  <h1 className="font-semibold text-neutral-50 text-2xl leading-8 tracking-tight">
                    Dubai Marina — Segmented Deep Dive
                  </h1>
                  <p className="text-[#9f9fa9] text-sm leading-5">
                    Dubai Marina · Net Yield Intelligence Overview
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <Button variant="secondary" className="rounded-xl gap-2">
                    <Download className="size-4" />
                    Export
                  </Button>
                  <Button className="rounded-xl bg-[#155dfc] text-[#1c398e] gap-2">
                    <FileText className="size-4" />
                    Generate Prospectus
                  </Button>
                </div>
              </div>
            </header>
            <main className="p-8 flex-1 overflow-hidden">
              <div className="flex flex-col gap-6 h-full">
                <div className="rounded-2xl bg-zinc-900 border-white/10 border-1 border-solid flex p-4 justify-between items-center gap-4">
                  <div className="text-[#9f9fa9] text-sm leading-5 flex items-center gap-4">
                    <div className="text-neutral-50 flex items-center gap-2">
                      <SlidersHorizontal className="size-4 text-[#155dfc]" />
                      Refine
                    </div>
                    <div className="flex items-center gap-2">
                      <span>Building Age</span>
                      <div className="min-w-[160px] rounded-xl bg-zinc-800 text-neutral-50 border-white/10 border-1 border-solid px-4 py-3">
                        Any age
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span>Unit Type</span>
                      <div className="min-w-[160px] rounded-xl bg-zinc-800 text-neutral-50 border-white/10 border-1 border-solid px-4 py-3">
                        All types
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span>Floor Range</span>
                      <div className="min-w-[160px] rounded-xl bg-zinc-800 text-neutral-50 border-white/10 border-1 border-solid px-4 py-3">
                        All floors
                      </div>
                    </div>
                  </div>
                  <Button variant="ghost" className="text-[#9f9fa9] gap-2">
                    <RotateCcw className="size-4" />
                    Reset
                  </Button>
                </div>
                <div className="grid grid-cols-[1.35fr_0.85fr] min-h-0 flex-1 gap-6">
                  <section className="relative min-h-0 rounded-3xl bg-zinc-900 border-white/10 border-1 border-solid overflow-hidden">
                    <img
                      src="https://screens-image-components-public.s3.eu-north-1.amazonaws.com/city-navigation-map.png"
                      alt="2D map canvas"
                      className="object-cover opacity-35 absolute inset-0 w-full h-full"
                    />
                    <div className="bg-[linear-gradient(180deg,oklch(0.141_0.005_285.823/.55),oklch(0.141_0.005_285.823/.72))] absolute inset-0" />
                    <div className="bg-[radial-gradient(circle_at_50%_42%,oklch(0.546_0.245_262.881/.18),transparent_34%),radial-gradient(circle_at_58%_52%,oklch(0.696_0.17_162.48/.18),transparent_22%)] absolute inset-0" />
                    <div className="backdrop-blur-sm rounded-full bg-zinc-800/90 border-white/10 border-1 border-solid flex absolute left-8 top-8 px-4 py-2 items-center gap-2">
                      <Layers3 className="size-4 text-[#155dfc]" />
                      <span className="text-neutral-50 text-sm leading-5">
                        Net Yield Overlay
                      </span>
                    </div>
                    <div className="backdrop-blur-sm rounded-full bg-zinc-800/90 text-amber-300 border-white/10 border-1 border-solid flex absolute right-8 top-8 px-4 py-2 items-center gap-2">
                      <AlertTriangle className="size-4" />
                      <span className="text-sm leading-5">
                        Query beyond DLD-covered bounds
                      </span>
                    </div>
                    <div className="flex absolute inset-0 justify-center items-center">
                      <div className="relative w-85 h-105">
                        <div className="bg-[linear-gradient(180deg,oklch(0.546_0.245_262.881/.18),oklch(0.274_0.006_286.033/.08))] blur-2xl rounded-[28px] absolute inset-0" />
                        <div className="left-[18%] top-[10%] w-[18%] h-[58%] bg-[linear-gradient(180deg,oklch(0.985_0_0/.95),oklch(0.274_0.006_286.033/.85))] shadow-[0_24px_60px_oklch(0_0_0/.45)] rounded-t-2xl rounded-b-md border-white/10 border-1 border-solid absolute" />
                        <div className="left-[38%] top-[18%] w-[22%] h-[48%] bg-[linear-gradient(180deg,oklch(0.985_0_0/.92),oklch(0.21_0.006_285.885/.9))] shadow-[0_24px_60px_oklch(0_0_0/.45)] rounded-t-2xl rounded-b-md border-white/10 border-1 border-solid absolute" />
                        <div className="left-[58%] top-[8%] w-[16%] h-[62%] bg-[linear-gradient(180deg,oklch(0.985_0_0/.96),oklch(0.274_0.006_286.033/.82))] shadow-[0_24px_60px_oklch(0_0_0/.45)] rounded-t-2xl rounded-b-md border-white/10 border-1 border-solid absolute" />
                        <div className="left-[28%] top-[42%] w-[26%] h-[28%] bg-[linear-gradient(180deg,oklch(0.696_0.17_162.48/.9),oklch(0.274_0.006_286.033/.75))] shadow-[0_0_40px_oklch(0.696_0.17_162.48/.35)] rounded-2xl border-white/10 border-1 border-solid absolute" />
                        <div className="left-[48%] top-[52%] w-[18%] h-[22%] bg-[linear-gradient(180deg,oklch(0.546_0.245_262.881/.9),oklch(0.274_0.006_286.033/.78))] shadow-[0_0_40px_oklch(0.546_0.245_262.881/.35)] rounded-2xl border-white/10 border-1 border-solid absolute" />
                        <div className="left-[62%] top-[34%] w-[14%] h-[34%] bg-[linear-gradient(180deg,oklch(0.788_0.14_195/.92),oklch(0.274_0.006_286.033/.78))] shadow-[0_0_40px_oklch(0.788_0.14_195/.35)] rounded-2xl border-white/10 border-1 border-solid absolute" />
                        <div className="left-[44%] top-[28%] size-16 blur-xl rounded-full bg-[#155dfc]/20 absolute" />
                        <div className="left-[46%] top-[30%] size-12 blur-xl rounded-full bg-[#00bc7d]/20 absolute" />
                      </div>
                    </div>
                    <div className="rounded-2xl bg-zinc-900/90 border-white/10 border-1 border-solid flex absolute left-8 bottom-8 px-4 py-3 items-center gap-3">
                      <div className="size-3 rounded-full bg-[#ff6467]" />
                      <div className="size-3 rounded-full bg-[#00bc7d]" />
                      <div className="size-3 rounded-full bg-[#9f9fa9]" />
                      <div className="flex ml-2 flex-col">
                        <span className="text-neutral-50 text-sm leading-5">
                          Yield Intensity
                        </span>
                        <span className="text-[#9f9fa9] text-xs leading-4">
                          Low 3% · High 9%+
                        </span>
                      </div>
                    </div>
                    <div className="rounded-2xl bg-zinc-800/90 text-[#9f9fa9] border-white/10 border-1 border-solid flex absolute right-8 bottom-8 px-4 py-3 items-center gap-2">
                      <LoaderCircle className="size-4 animate-spin text-[#155dfc]" />
                      <span className="text-sm leading-5">
                        Re-rendering polygon density via PostGIS...
                      </span>
                    </div>
                    <div className="top-1/2 -translate-y-1/2 flex absolute right-6 flex-col gap-2">
                      <Button
                        size="icon"
                        variant="secondary"
                        className="rounded-xl"
                      >
                        <Plus className="size-4" />
                      </Button>
                      <Button
                        size="icon"
                        variant="secondary"
                        className="rounded-xl"
                      >
                        <Minus className="size-4" />
                      </Button>
                      <Button
                        size="icon"
                        variant="secondary"
                        className="rounded-xl"
                      >
                        <Compass className="size-4" />
                      </Button>
                    </div>
                  </section>
                  <aside className="min-h-0 rounded-3xl bg-zinc-900 border-white/10 border-1 border-solid flex p-6 flex-col gap-6 overflow-hidden">
                    <div className="flex justify-between items-start gap-4">
                      <div>
                        <h2 className="font-semibold text-neutral-50 text-xl leading-7">
                          Buildings in Community
                        </h2>
                        <p className="text-[#9f9fa9] text-sm leading-5">
                          Click a row to highlight its polygon on the map
                        </p>
                      </div>
                      <Badge className="rounded-full bg-zinc-800 text-neutral-50 border-white/10 border-1 border-solid px-3 py-1">
                        34 towers
                      </Badge>
                    </div>
                    <div className="grid grid-cols-[1.4fr_0.8fr_0.8fr_0.6fr] text-[#9f9fa9] text-sm leading-5 px-2 gap-4">
                      <span>Building</span>
                      <span>Avg Yield</span>
                      <span>SC/Sq Ft</span>
                      <span>Units</span>
                    </div>
                    <div className="flex flex-col gap-1 overflow-hidden">
                      <div className="grid grid-cols-[1.4fr_0.8fr_0.8fr_0.6fr] rounded-xl bg-zinc-800/70 text-sm leading-5 border-white/10 border-1 border-solid p-3 items-center gap-4">
                        <span className="font-medium text-neutral-50">
                          Marina Gate 1
                        </span>
                        <span className="font-medium text-[#155dfc]">
                          8.42%
                        </span>
                        <span className="text-neutral-50">AED 16.2</span>
                        <span className="text-neutral-50">412</span>
                      </div>
                      <div className="grid grid-cols-[1.4fr_0.8fr_0.8fr_0.6fr] text-sm leading-5 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid p-3 items-center gap-4">
                        <span className="text-neutral-50">Cayan Tower</span>
                        <span className="font-medium text-[#155dfc]">
                          7.91%
                        </span>
                        <span className="text-neutral-50">AED 19.8</span>
                        <span className="text-neutral-50">495</span>
                      </div>
                      <div className="grid grid-cols-[1.4fr_0.8fr_0.8fr_0.6fr] text-sm leading-5 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid p-3 items-center gap-4">
                        <span className="text-neutral-50">Princess Tower</span>
                        <span className="font-medium text-[#155dfc]">
                          7.35%
                        </span>
                        <span className="text-neutral-50">AED 22.1</span>
                        <span className="text-neutral-50">763</span>
                      </div>
                      <div className="grid grid-cols-[1.4fr_0.8fr_0.8fr_0.6fr] text-sm leading-5 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid p-3 items-center gap-4">
                        <span className="text-neutral-50">Marina Pinnacle</span>
                        <span className="font-medium text-[#155dfc]">
                          6.88%
                        </span>
                        <span className="text-neutral-50">AED 15.4</span>
                        <span className="text-neutral-50">548</span>
                      </div>
                      <div className="grid grid-cols-[1.4fr_0.8fr_0.8fr_0.6fr] text-sm leading-5 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid p-3 items-center gap-4">
                        <span className="text-neutral-50">Sulafa Tower</span>
                        <span className="text-[#9f9fa9]">6.12%</span>
                        <span className="text-neutral-50">AED 21.7</span>
                        <span className="text-neutral-50">336</span>
                      </div>
                      <div className="grid grid-cols-[1.4fr_0.8fr_0.8fr_0.6fr] text-sm leading-5 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid p-3 items-center gap-4">
                        <span className="text-neutral-50">Ocean Heights</span>
                        <span className="text-[#9f9fa9]">5.74%</span>
                        <span className="text-neutral-50">AED 24.9</span>
                        <span className="text-neutral-50">519</span>
                      </div>
                      <div className="grid grid-cols-[1.4fr_0.8fr_0.8fr_0.6fr] text-sm leading-5 border-white/10 border-t-0 border-r-0 border-b-1 border-l-0 border-solid p-3 items-center gap-4">
                        <span className="text-neutral-50">Elite Residence</span>
                        <span className="text-[#9f9fa9]">5.31%</span>
                        <span className="text-neutral-50">AED 26.3</span>
                        <span className="text-neutral-50">695</span>
                      </div>
                    </div>
                    <div className="text-center rounded-2xl bg-zinc-950/40 border-white/10 border-1 border-dashed flex mt-auto p-6 flex-col justify-center items-center gap-2">
                      <SearchX className="size-8 text-[#9f9fa9]" />
                      <span className="font-medium text-neutral-50">
                        No buildings match current filter
                      </span>
                      <span className="text-[#9f9fa9] text-sm leading-5">
                        Adjust the age, unit type, or floor range to see results
                      </span>
                      <Button
                        variant="secondary"
                        className="rounded-xl mt-2 gap-2"
                      >
                        <RotateCcw className="size-4" />
                        Clear filters
                      </Button>
                    </div>
                    <div className="text-[#9f9fa9] text-sm leading-5 flex justify-between items-center">
                      <span>Showing 7 of 34</span>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="rounded-full"
                        >
                          <ChevronLeft className="size-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="rounded-full"
                        >
                          <ChevronRight className="size-4" />
                        </Button>
                      </div>
                    </div>
                  </aside>
                </div>
              </div>
            </main>
            <div className="z-20 backdrop-blur-xl bg-zinc-950/70 flex absolute inset-0 justify-center items-center">
              <Card className="shadow-[0_24px_80px_oklch(0_0_0/.45)] rounded-3xl bg-zinc-900 border-white/10 border-1 border-solid p-8 gap-6 w-115">
                <CardHeader className="text-center p-0 items-center gap-3">
                  <div className="size-12 rounded-full bg-[#155dfc]/15 flex justify-center items-center">
                    <CheckCircle2 className="size-6 text-[#00bc7d]" />
                  </div>
                  <CardTitle className="text-neutral-50 text-xl leading-7">
                    Prospectus Ready
                  </CardTitle>
                  <CardDescription className="text-[#9f9fa9] text-sm leading-5">
                    The Prism Tower · Makani 2874 92834 investor package has
                    been compiled.
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex p-0 flex-col gap-4">
                  <div className="flex flex-col gap-2">
                    <span className="text-[#9f9fa9] text-xs leading-4">
                      Compiling DLD dataset
                    </span>
                    <Progress value={100} className="bg-zinc-800 h-2" />
                  </div>
                  <div className="rounded-2xl bg-zinc-950/60 border-white/10 border-1 border-solid flex px-4 py-3 items-center gap-3">
                    <Link className="size-4 text-[#9f9fa9]" />
                    <span className="truncate text-neutral-50 text-sm leading-5 flex-1">
                      terra.io/p/prism-tower-2874
                    </span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="size-8 text-[#9f9fa9]"
                    >
                      <Copy className="size-4" />
                    </Button>
                  </div>
                </CardContent>
                <CardFooter className="p-0 gap-3">
                  <Button className="rounded-xl bg-[#155dfc] text-[#1c398e] flex-1 gap-2">
                    <Download className="size-4" />
                    Download PDF
                  </Button>
                  <Button variant="secondary" className="rounded-xl gap-2">
                    <Mail className="size-4" />
                    Email Share
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

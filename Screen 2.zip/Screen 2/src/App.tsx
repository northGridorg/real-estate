import { useEffect } from "react";
import {
  ArrowLeft,
  BarChart3,
  Building2,
  ChevronLeft,
  ChevronRight,
  ChevronsUpDown,
  Download,
  FileText,
  Filter,
  Globe,
  Layers3,
  LayoutDashboard,
  LoaderCircle,
  Map,
  Minus,
  Plus,
  RotateCcw,
  SearchX,
  Settings,
  SlidersHorizontal,
  TriangleAlert,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function App() {
  return (
    <div>
      <div className="bg-zinc-950 text-neutral-50 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <div className="min-h-[1080px] bg-zinc-950 flex w-full">
          <aside className="shrink-0 bg-zinc-900 border-white/10 border-t-0 border-r-1 border-b-0 border-l-0 border-solid flex p-6 flex-col gap-8 w-72">
            <div className="flex items-center gap-3">
              <div className="size-10 ring-1 ring-primary/40 rounded-xl bg-[#155dfc]/20 flex justify-center items-center">
                <Globe className="size-5 text-[#155dfc]" />
              </div>
              <div className="flex flex-col">
                <span className="font-semibold text-neutral-50 text-sm leading-5">
                  Meridian Capital
                </span>
                <span className="text-[#9f9fa9] text-xs leading-4">
                  Investment Intelligence
                </span>
              </div>
            </div>
            <nav className="flex flex-col gap-1">
              <Button
                variant="ghost"
                className="text-[#9f9fa9] p-2 justify-start gap-2"
              >
                <LayoutDashboard className="size-4" />
                Dashboard
              </Button>
              <Button
                variant="ghost"
                className="bg-zinc-800 text-neutral-50 p-2 justify-start gap-2"
              >
                <Map className="size-4 text-[#155dfc]" />
                Communities
              </Button>
              <Button
                variant="ghost"
                className="text-[#9f9fa9] p-2 justify-start gap-2"
              >
                <Building2 className="size-4" />
                Assets
              </Button>
              <Button
                variant="ghost"
                className="text-[#9f9fa9] p-2 justify-start gap-2"
              >
                <Filter className="size-4" />
                Sourcing Matrix
              </Button>
              <Button
                variant="ghost"
                className="text-[#9f9fa9] p-2 justify-start gap-2"
              >
                <FileText className="size-4" />
                Prospectus
              </Button>
              <Button
                variant="ghost"
                className="text-[#9f9fa9] p-2 justify-start gap-2"
              >
                <BarChart3 className="size-4" />
                Reports
              </Button>
              <Button
                variant="ghost"
                className="text-[#9f9fa9] p-2 justify-start gap-2"
              >
                <Settings className="size-4" />
                Settings
              </Button>
            </nav>
            <div className="rounded-2xl bg-zinc-900 border-white/10 border-1 border-solid flex mt-auto p-4 items-center gap-3">
              <div className="size-10 rounded-full bg-zinc-800 overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1511367461989-f85a21fda167?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3OTAzMTh8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHByb2ZpbGUlMjBhdmF0YXJ8ZW58MXx8fHwxNzU0OTIzNzc3fDA&ixlib=rb-4.1.0&q=80&w=400"
                  alt="Profile avatar"
                  className="object-cover w-full h-full"
                  data-photoid="xQw7vQxQ2mA"
                  data-authorname="LinkedIn Sales Solutions"
                  data-authorurl="https://unsplash.com/@linkedinsalesnavigator"
                  data-blurhash="L6PZ%2?=^%2?=^%2?=^%2?=^%2?=^"
                />
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate font-medium text-neutral-50 text-sm leading-5">
                  A. Rahman
                </div>
                <div className="truncate text-[#9f9fa9] text-xs leading-4">
                  Portfolio Lead
                </div>
              </div>
              <ChevronsUpDown className="size-4 text-[#9f9fa9]" />
            </div>
          </aside>
          <main className="min-w-0 bg-zinc-950 flex p-8 flex-col flex-1 gap-6">
            <div className="flex justify-between items-center">
              <div className="flex flex-col gap-2">
                <nav className="text-[#9f9fa9] text-sm leading-5 flex items-center gap-2">
                  <button className="flex items-center gap-1">
                    <ArrowLeft className="size-4" />
                    Global Dashboard
                  </button>
                  <ChevronRight className="size-4" />
                  <span className="font-medium text-neutral-50">
                    Dubai Marina
                  </span>
                </nav>
                <h1 className="font-semibold text-neutral-50 text-2xl leading-8">
                  Dubai Marina — Segmented Deep Dive
                </h1>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="secondary" className="p-2 gap-2">
                  <Download className="size-4" />
                  Export
                </Button>
                <Button className="bg-[#155dfc] text-[#1c398e] p-2 gap-2">
                  <FileText className="size-4" />
                  Generate Prospectus
                </Button>
              </div>
            </div>
            <div className="rounded-xl bg-zinc-900 border-white/10 border-1 border-solid flex p-4 items-center gap-4">
              <div className="text-[#9f9fa9] text-sm leading-5 flex items-center gap-2">
                <SlidersHorizontal className="size-4 text-[#155dfc]" />
                Refine
              </div>
              <div className="flex items-center gap-2">
                <label className="text-[#9f9fa9] text-xs leading-4">
                  Building Age
                </label>
                <Select>
                  <SelectTrigger className="bg-zinc-800 border-white/10 border-0 border-solid w-40">
                    <SelectValue placeholder="Any age" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="new">0-5 years</SelectItem>
                    <SelectItem value="mid">5-15 years</SelectItem>
                    <SelectItem value="old">15+ years</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-2">
                <label className="text-[#9f9fa9] text-xs leading-4">
                  Unit Type
                </label>
                <Select>
                  <SelectTrigger className="bg-zinc-800 border-white/10 border-0 border-solid w-40">
                    <SelectValue placeholder="All types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="studio">Studio</SelectItem>
                    <SelectItem value="1br">1 Bedroom</SelectItem>
                    <SelectItem value="2br">2 Bedroom</SelectItem>
                    <SelectItem value="3br">3+ Bedroom</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-2">
                <label className="text-[#9f9fa9] text-xs leading-4">
                  Floor Range
                </label>
                <Select>
                  <SelectTrigger className="bg-zinc-800 border-white/10 border-0 border-solid w-40">
                    <SelectValue placeholder="All floors" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">1-10</SelectItem>
                    <SelectItem value="mid">11-30</SelectItem>
                    <SelectItem value="high">31+</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button
                variant="ghost"
                className="text-[#9f9fa9] ml-auto p-2 gap-2"
              >
                <RotateCcw className="size-4" />
                Reset
              </Button>
            </div>
            <div className="grid grid-cols-[1.35fr_1fr] min-h-0 flex-1 gap-6">
              <Card className="relative min-h-[760px] bg-zinc-900 border-white/10 border-0 border-solid p-0 gap-0 overflow-hidden">
                <div className="bg-[radial-gradient(circle_at_50%_35%,oklch(0.546_0.245_262.881/.18),transparent_42%),linear-gradient(180deg,oklch(0.141_0.005_285.823/.15),oklch(0.141_0.005_285.823/.72))] absolute inset-0" />
                <img
                  src="https://images.unsplash.com/photo-1512453979798-5ea266f8880c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3OTAzMTh8MHwxfHNlYXJjaHwxfHxkdWJhaSUyMG1hcmluYSUyMG5pZ2h0JTIwYWVyaWFsJTIwYnVpbGRpbmdzfGVufDF8fHx8MTc1NDkyMzc3N3ww&ixlib=rb-4.1.0&q=80&w=400"
                  alt="Dubai Marina top-down map"
                  className="object-cover opacity-35 absolute inset-0 w-full h-full"
                  data-photoid="Qm9mQm9mQm9"
                  data-authorname="Nicolas J Leclercq"
                  data-authorurl="https://unsplash.com/@nicolasjleclercq"
                  data-blurhash="L9B4x^?b?b?b?b?b?b?b?b?b?b"
                />
                <div className="bg-[linear-gradient(180deg,oklch(0.141_0.005_285.823/.18),oklch(0.141_0.005_285.823/.55))] absolute inset-0" />
                <div className="absolute inset-0">
                  <div className="left-[18%] top-[18%] bg-[linear-gradient(180deg,oklch(0.488_0.243_264.376/.95),oklch(0.488_0.243_264.376/.35))] shadow-[0_0_40px_oklch(0.488_0.243_264.376/.35)] rounded-xl border-[#155dfc]/30 border-1 border-solid absolute w-24 h-44" />
                  <div className="left-[28%] top-[24%] bg-[linear-gradient(180deg,oklch(0.696_0.17_162.48/.95),oklch(0.696_0.17_162.48/.28))] shadow-[0_0_48px_oklch(0.696_0.17_162.48/.35)] border-[oklch(0.696_0.17_162.48/.35)] rounded-xl border-black/1 border-1 border-solid absolute w-28 h-56" />
                  <div className="left-[40%] top-[16%] bg-[linear-gradient(180deg,oklch(0.627_0.265_303.9/.95),oklch(0.627_0.265_303.9/.25))] shadow-[0_0_52px_oklch(0.627_0.265_303.9/.28)] border-[oklch(0.627_0.265_303.9/.35)] rounded-xl border-black/1 border-1 border-solid absolute w-28 h-64" />
                  <div className="left-[52%] top-[28%] bg-[linear-gradient(180deg,oklch(0.546_0.245_262.881/.95),oklch(0.546_0.245_262.881/.22))] shadow-[0_0_44px_oklch(0.546_0.245_262.881/.3)] rounded-xl border-[#155dfc]/30 border-1 border-solid absolute w-24 h-52" />
                  <div className="left-[62%] top-[20%] bg-[linear-gradient(180deg,oklch(0.769_0.188_70.08/.95),oklch(0.769_0.188_70.08/.22))] shadow-[0_0_56px_oklch(0.769_0.188_70.08/.28)] border-[oklch(0.769_0.188_70.08/.35)] rounded-xl border-black/1 border-1 border-solid absolute w-30 h-72" />
                  <div className="left-[72%] top-[34%] bg-[linear-gradient(180deg,oklch(0.705_0.015_286.067/.9),oklch(0.705_0.015_286.067/.18))] rounded-xl border-white/10 border-1 border-solid absolute w-22 h-40" />
                  <div className="left-[46%] top-[48%] bg-[linear-gradient(180deg,oklch(0.696_0.17_162.48/.9),oklch(0.696_0.17_162.48/.18))] border-[oklch(0.696_0.17_162.48/.35)] shadow-[0_0_30px_oklch(0.696_0.17_162.48/.25)] rounded-xl border-black/1 border-1 border-solid absolute w-20 h-28" />
                  <div className="left-[34%] top-[58%] bg-[linear-gradient(180deg,oklch(0.488_0.243_264.376/.9),oklch(0.488_0.243_264.376/.18))] rounded-xl border-[#155dfc]/30 border-1 border-solid absolute w-22 h-36" />
                  <div className="left-[58%] top-[58%] bg-[linear-gradient(180deg,oklch(0.627_0.265_303.9/.9),oklch(0.627_0.265_303.9/.18))] border-[oklch(0.627_0.265_303.9/.35)] rounded-xl border-black/1 border-1 border-solid absolute w-24 h-44" />
                  <div className="left-[22%] top-[42%] bg-[linear-gradient(180deg,oklch(0.705_0.015_286.067/.85),oklch(0.705_0.015_286.067/.16))] rounded-lg border-white/10 border-1 border-solid absolute w-18 h-24" />
                  <div className="left-[66%] top-[46%] bg-[linear-gradient(180deg,oklch(0.546_0.245_262.881/.9),oklch(0.546_0.245_262.881/.16))] rounded-lg border-[#155dfc]/30 border-1 border-solid absolute w-20 h-30" />
                </div>
                <div className="backdrop-blur-md rounded-lg bg-zinc-900/80 text-neutral-50 text-xs leading-4 border-white/10 border-1 border-solid flex absolute left-6 top-6 px-3 py-2 items-center gap-2">
                  <Layers3 className="size-3.5 text-[#155dfc]" />
                  Net Yield Overlay
                </div>
                <div className="flex absolute right-6 top-6 flex-col gap-2">
                  <Button size="icon" variant="secondary" className="size-10">
                    <Plus className="size-4" />
                  </Button>
                  <Button size="icon" variant="secondary" className="size-10">
                    <Minus className="size-4" />
                  </Button>
                </div>
                <div className="flex absolute left-6 bottom-6 flex-col gap-3">
                  <div className="backdrop-blur-md rounded-xl bg-zinc-900/80 border-white/10 border-1 border-solid flex px-4 py-3 items-center gap-3 w-fit">
                    <div className="flex items-center gap-2">
                      <span className="size-3 bg-[oklch(0.696_0.17_162.48)] rounded-sm" />
                      <span className="text-neutral-50 text-xs leading-4">
                        Top Performer
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="size-3 bg-[oklch(0.696_0.17_162.48/.4)] rounded-sm" />
                      <span className="text-[#9f9fa9] text-xs leading-4">
                        Moderate
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="size-3 bg-[oklch(0.705_0.015_286.067/.4)] rounded-sm" />
                      <span className="text-[#9f9fa9] text-xs leading-4">
                        Underperformer
                      </span>
                    </div>
                  </div>
                  <div className="backdrop-blur-md rounded-lg bg-zinc-900/80 text-[#9f9fa9] text-xs leading-4 border-white/10 border-1 border-solid flex px-3 py-2 items-center gap-2 w-fit">
                    <LoaderCircle className="size-3.5 animate-spin text-[#155dfc]" />
                    Re-rendering polygon density via PostGIS…
                  </div>
                </div>
                <div className="backdrop-blur-md rounded-xl bg-zinc-900/80 border-white/10 border-1 border-solid absolute left-6 bottom-24 px-4 py-3 w-56">
                  <div className="text-neutral-50 text-xs leading-4 flex justify-between items-center">
                    <span>Yield Intensity</span>
                    <span className="text-[#9f9fa9]">Low 3%</span>
                  </div>
                  <div className="rounded-full bg-zinc-800 mt-2 h-2 overflow-hidden">
                    <div className="w-[78%] bg-[linear-gradient(90deg,oklch(0.704_0.191_22.216),oklch(0.769_0.188_70.08),oklch(0.696_0.17_162.48))] rounded-full h-full" />
                  </div>
                  <div className="text-[#9f9fa9] text-xs leading-4 flex mt-2 justify-end">
                    High 9%+
                  </div>
                </div>
                <div className="rounded-lg bg-[#ff6467]/10 text-[#ff6467] text-xs leading-4 border-[#ff6467]/40 border-1 border-solid flex absolute right-6 bottom-6 px-3 py-2 items-center gap-2">
                  <TriangleAlert className="size-3.5" />
                  Query beyond DLD-covered bounds
                </div>
              </Card>
              <Card className="bg-zinc-900 border-white/10 border-0 border-solid p-6 gap-4">
                <CardHeader className="p-0 gap-1">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-neutral-50 text-base leading-6">
                      Buildings in Community
                    </CardTitle>
                    <Badge variant="secondary" className="text-xs leading-4">
                      34 towers
                    </Badge>
                  </div>
                  <CardDescription className="text-[#9f9fa9] text-xs leading-4">
                    Click a row to highlight its polygon on the map
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-0 gap-0">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-white/10 border-0 border-solid">
                        <TableHead className="text-[#9f9fa9]">
                          Building
                        </TableHead>
                        <TableHead className="text-right text-[#9f9fa9]">
                          Avg Yield
                        </TableHead>
                        <TableHead className="text-right text-[#9f9fa9]">
                          SC/Sq Ft
                        </TableHead>
                        <TableHead className="text-right text-[#9f9fa9]">
                          Units
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow className="cursor-pointer bg-[#155dfc]/10 border-white/10 border-0 border-solid">
                        <TableCell className="font-medium text-neutral-50">
                          Marina Gate 1
                        </TableCell>
                        <TableCell className="font-semibold text-right text-[#155dfc]">
                          8.42%
                        </TableCell>
                        <TableCell className="text-right text-[#9f9fa9]">
                          AED 16.2
                        </TableCell>
                        <TableCell className="text-right text-[#9f9fa9]">
                          412
                        </TableCell>
                      </TableRow>
                      <TableRow className="cursor-pointer border-white/10 border-0 border-solid">
                        <TableCell className="font-medium text-neutral-50">
                          Cayan Tower
                        </TableCell>
                        <TableCell className="font-semibold text-right text-[#155dfc]">
                          7.91%
                        </TableCell>
                        <TableCell className="text-right text-[#9f9fa9]">
                          AED 19.8
                        </TableCell>
                        <TableCell className="text-right text-[#9f9fa9]">
                          495
                        </TableCell>
                      </TableRow>
                      <TableRow className="cursor-pointer border-white/10 border-0 border-solid">
                        <TableCell className="font-medium text-neutral-50">
                          Princess Tower
                        </TableCell>
                        <TableCell className="font-semibold text-right text-[#155dfc]">
                          7.35%
                        </TableCell>
                        <TableCell className="text-right text-[#9f9fa9]">
                          AED 22.1
                        </TableCell>
                        <TableCell className="text-right text-[#9f9fa9]">
                          763
                        </TableCell>
                      </TableRow>
                      <TableRow className="cursor-pointer border-white/10 border-0 border-solid">
                        <TableCell className="font-medium text-neutral-50">
                          Marina Pinnacle
                        </TableCell>
                        <TableCell className="font-semibold text-right text-[#155dfc]">
                          6.88%
                        </TableCell>
                        <TableCell className="text-right text-[#9f9fa9]">
                          AED 15.4
                        </TableCell>
                        <TableCell className="text-right text-[#9f9fa9]">
                          548
                        </TableCell>
                      </TableRow>
                      <TableRow className="cursor-pointer border-white/10 border-0 border-solid">
                        <TableCell className="font-medium text-neutral-50">
                          Sulafa Tower
                        </TableCell>
                        <TableCell className="text-right text-neutral-50">
                          6.12%
                        </TableCell>
                        <TableCell className="text-right text-[#9f9fa9]">
                          AED 21.7
                        </TableCell>
                        <TableCell className="text-right text-[#9f9fa9]">
                          336
                        </TableCell>
                      </TableRow>
                      <TableRow className="cursor-pointer border-white/10 border-0 border-solid">
                        <TableCell className="font-medium text-neutral-50">
                          Ocean Heights
                        </TableCell>
                        <TableCell className="text-right text-[#9f9fa9]">
                          5.74%
                        </TableCell>
                        <TableCell className="text-right text-[#9f9fa9]">
                          AED 24.9
                        </TableCell>
                        <TableCell className="text-right text-[#9f9fa9]">
                          519
                        </TableCell>
                      </TableRow>
                      <TableRow className="cursor-pointer border-white/10 border-0 border-solid">
                        <TableCell className="font-medium text-neutral-50">
                          Elite Residence
                        </TableCell>
                        <TableCell className="text-right text-[#9f9fa9]">
                          5.31%
                        </TableCell>
                        <TableCell className="text-right text-[#9f9fa9]">
                          AED 26.3
                        </TableCell>
                        <TableCell className="text-right text-[#9f9fa9]">
                          695
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                  <div className="rounded-xl border-white/10 border-1 border-dashed flex mt-6 p-8 flex-col justify-center items-center gap-2">
                    <div className="size-12 rounded-full bg-zinc-800 flex justify-center items-center">
                      <SearchX className="size-6 text-[#9f9fa9]" />
                    </div>
                    <span className="font-medium text-neutral-50 text-sm leading-5">
                      No buildings match current filter
                    </span>
                    <span className="text-[#9f9fa9] text-xs leading-4">
                      Adjust the age, unit type, or floor range to see results
                    </span>
                    <Button variant="secondary" className="mt-1 p-2 gap-2">
                      <RotateCcw className="size-4" />
                      Clear filters
                    </Button>
                  </div>
                </CardContent>
                <CardFooter className="p-0 justify-between gap-2">
                  <span className="text-[#9f9fa9] text-xs leading-4">
                    Showing 7 of 34
                  </span>
                  <div className="flex items-center gap-1">
                    <Button size="icon" variant="ghost" className="size-8">
                      <ChevronLeft className="size-4" />
                    </Button>
                    <Button size="icon" variant="ghost" className="size-8">
                      <ChevronRight className="size-4" />
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}
